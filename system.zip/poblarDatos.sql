INSERT INTO `fa_ciudad` (`atr_nombre`)
VALUES ('Arica'),('Camarones'),('General Lagos'),('Putre'),('Alto Hospicio'),('Iquique'),('Camiña'),('Colchane'),('Huara'),('Pica'),('Pozo Almonte'),('Tocopilla'),('María Elena'),
	('Calama'),('Ollague'),('San Pedro de Atacama'),('Antofagasta'),('Mejillones'),('Sierra Gorda'),('Taltal'),('Chañaral'),('Diego de Almagro'),('Copiapó'),
	('Caldera'),('Tierra Amarilla'),('Vallenar'),('Alto del Carmen'),('Freirina'),('Huasco'),('La Serena'),('Coquimbo'),('Andacollo'),('La Higuera'),
  ('Paihuano'),('Vicuña'),('Ovalle'),('Combarbalá'),('Monte Patria'),('Punitaqui'),('Río Hurtado'),('Illapel'),('Canela'),('Los Vilos'),('Salamanca'),
	('La Ligua'),('Cabildo'),('Zapallar'),('Papudo'),('Petorca'),('Los Andes'),('San Esteban'),('Calle Larga'),('Rinconada'),('San Felipe'),
  ('Llaillay'),('Putaendo'),('Santa María'),('Catemu'),('Panquehue'),('Quillota'),('La Cruz'),('La Calera'),('Nogales'),('Hijuelas'),('Valparaíso'),
  ('Viña del Mar'),('Concón'),('Quintero'),('Puchuncaví'),('Casablanca'),('Juan Fernández'),('San Antonio'),('Cartagena'),('El Tabo'),('El Quisco'),('Algarrobo'),
	('Santo Domingo'),('Isla de Pascua'),('Quilpué'),('Limache'),('Olmué'),('Villa Alemana'),('Colina'),('Lampa'),('Tiltil'),('Santiago'),('Vitacura'),
  ('San Ramón'),('San Miguel'),('San Joaquín'),('Renca'),('Recoleta'),('Quinta Normal'),('Quilicura'),('Pudahuel'),('Providencia'),('Peñalolén'),
  ('Pedro Aguirre Cerda'),('Ñuñoa'),('Maipú'),('Macul'),('Lo Prado'),('Lo Espejo'),('Lo Barnechea'),('Las Condes'),('La Reina'),('La Pintana'),
	('La Granja'),('La Florida'),('La Cisterna'),('Independencia'),('Huechuraba'),('Estación Central'),('El Bosque'),('Conchalí'),('Cerro Navia'),
  ('Cerrillos'),('Puente Alto'),('San José de Maipo'),('Pirque'),('San Bernardo'),('Buin'),('Paine'),('Calera de Tango'),('Melipilla'),('Alhué'),
	('Curacaví'),('María Pinto'),('San Pedro'),('Isla de Maipo'),('El Monte'),('Padre Hurtado'),('Peñaflor'),('Talagante'),('Codegua'),('Coínco'),('Coltauco'),
	('Doñihue'),('Graneros'),('Las Cabras'),('Machalí'),('Malloa'),('Mostazal'),('Olivar'),('Peumo'),('Pichidegua'),('Quinta de Tilcoco'),
	('Rancagua'),('Rengo'),('Requínoa'),('San Vicente de Tagua Tagua'),('Chépica'),('Chimbarongo'),('Lolol'),('Nancagua'),('Palmilla'),('Peralillo'),
	('Placilla'),('Pumanque'),('San Fernando'),('Santa Cruz'),('La Estrella'),('Litueche'),('Marchigüe'),('Navidad'),('Paredones'),('Pichilemu'),
	('Curicó'),('Hualañé'),('Licantén'),('Molina'),('Rauco'),('Romeral'),('Sagrada Familia'),('Teno'),('Vichuquén'),('Talca'),('San Clemente'),('Pelarco'),
	('Pencahue'),('Maule'),('San Rafael'),('Curepto'),('Constitución'),('Empedrado'),('Río Claro'),('Linares'),('San Javier'),('Parral'),('Villa Alegre'),
	('Longaví'),('Colbún'),('Retiro'),('Yerbas Buenas'),('Cauquenes'),('Chanco'),('Pelluhue'),('Bulnes'),('Chillán'),('Chillán Viejo'),('El Carmen'),
	('Pemuco'),('Pinto'),('Quillón'),('San Ignacio'),('Yungay'),('Cobquecura'),('Coelemu'),('Ninhue'),('Portezuelo'),('Quirihue'),('Ránquil'),('Treguaco'),
	('San Carlos'),('Coihueco'),('San Nicolás'),('Ñiquén'),('San Fabián'),('Alto Biobío'),('Antuco'),('Cabrero'),('Laja'),('Los Ángeles'),('Mulchén'),
	('Nacimiento'),('Negrete'),('Quilaco'),('Quilleco'),('San Rosendo'),('Santa Bárbara'),('Tucapel'),('Yumbel'),('Concepción'),('Coronel'),('Chiguayante'),
	('Florida'),('Hualpén'),('Hualqui'),('Lota'),('Penco'),('San Pedro de La Paz'),('Santa Juana'),('Talcahuano'),('Tomé'),
	('Arauco'),('Cañete'),('Contulmo'),('Curanilahue'),('Lebu'),('Los Álamos'),('Tirúa'),('Angol'),('Collipulli'),('Curacautín'),('Ercilla'),('Lonquimay'),
	('Los Sauces'),('Lumaco'),('Purén'),('Renaico'),('Traiguén'),('Victoria'),('Temuco'),('Carahue'),('Cholchol'),('Cunco'),('Curarrehue'),
	('Freire'),('Galvarino'),('Gorbea'),('Lautaro'),('Loncoche'),('Melipeuco'),('Nueva Imperial'),('Padre Las Casas'),('Perquenco'),
	('Pitrufquén'),('Pucón'),('Saavedra'),('Teodoro Schmidt'),('Toltén'),('Vilcún'),('Villarrica'),('Valdivia'),('Corral'),('Lanco'),('Los Lagos'),
	('Máfil'),('Mariquina'),('Paillaco'),('Panguipulli'),('La Unión'),('Futrono'),('Lago Ranco'),('Río Bueno'),('Osorno'),('Puerto Octay'),('Purranque'),
	('Puyehue'),('Río Negro'),('San Juan de la Costa'),('San Pablo'),('Calbuco'),('Cochamó'),('Fresia'),('Frutillar'),('Llanquihue'),('Los Muermos'),
	('Maullín'),('Puerto Montt'),('Puerto Varas'),('Ancud'),('Castro'),('Chonchi'),('Curaco de Vélez'),('Dalcahue'),('Puqueldón'),('Queilén'),('Quellón'),
	('Quemchi'),('Quinchao'),('Chaitén'),('Futaleufú'),('Hualaihué'),('Palena'),('Lago Verde'),('Coihaique'),('Aysén'),('Cisnes'),('Guaitecas'),
	('Río Ibáñez'),('Chile Chico'),('Cochrane'),('Higgins'),('Tortel'),('Natales'),('Torres del Paine'),('Laguna Blanca'),('Punta Arenas'),
  ('Río Verde'),('San Gregorio'),('Porvenir'),('Primavera'),('Timaukel'),('Cabo de Hornos'),('Antártica');


INSERT INTO `fa_afp` (`cp_afp`, `atr_nombre`) VALUES (NULL, 'Capital'), (NULL, 'Cuprum'), (NULL, 'Habitat'), (NULL, 'Modelo'), (NULL, 'Planvital'), (NULL, 'Provida');

INSERT INTO `fa_cargo` (`cp_cargo`, `atr_nombre`, `atr_jefeDirecto`, `atr_lugarTrabajo`, `atr_jornadaTrabajo`, `atr_diasTrabajo`) VALUES (NULL, 'Ejecutivo de licitaciones publicas y privadas', 'Solanch Tejos Carrasco', NULL, 'Horario de mañana: 9 a 13:00 horas, horario de tarde: 14:00 a 19:00 horas', 'De lunes a viernes de 09:00 hasta las 19:00 horas. Sábados de 09:00 a 14:00 horas'), (NULL, 'Recepcionista administrativa Rent A Car Maule', 'Diego Vargas, Miguel Vargas, Solanch Tejos', NULL, 'Turno de mañana: 09:00 a 13:00 horas. Turno de tarde 14:00 a 19:00 horas', NULL), (NULL, 'Cartero', 'Evelyn Gallegos, Nelvis Villalobos', NULL, '09:00 a 14:00 horas - 15:00 a 19:00 horas.', NULL);

INSERT INTO `fa_remuneracion` (`cp_remuneracion`, `atr_sueldoMensual`, `atr_cotizaciones`, `atr_colacion`, `atr_movilizacion`, `cf_cargo`) VALUES (NULL, '301.000', '1', '0', '0', '1'), (NULL, '600.000', '1', '0', '0', '2'), (NULL, '301.000', '1', '0', '0', '3');

INSERT INTO `fa_competencia` (`cp_competencia`, `atr_descripcion`) VALUES (NULL, 'Capacidad para aprender a manejar sistemas informáticos'), (NULL, 'Organizada y metódica'), (NULL, 'Capadidad para trabajar en equipo'), (NULL, 'Vocación de servicio, compromiso con el trabajo y la institución.'), (NULL, 'Habilidades en el lenguaje oral y escrito, tanto en fluidez como en claridad.'), (NULL, 'Buen racionamiento interpersonal.'), (NULL, 'Autodidacta y proactiva');

INSERT INTO `fa_competencia_cargo` (`cp_competencia_cargo`, `cf_cargo`, `cf_competencia`) VALUES (NULL, '1', '7'), (NULL, '1', '6'), (NULL, '1', '1'), (NULL, '1', '3'), (NULL, '1', '5'), (NULL, '1', '2'), (NULL, '1', '4');

INSERT INTO `fa_requisitominimo` (`cp_requisitominimo`, `atr_descripcion`) VALUES (NULL, 'Bachillerato en educación media, concluido.'), (NULL, 'Título universitaro de Ingeniero Comercial, Civil industrial, Ingeniero de ejecución en administración o similar.'), (NULL, 'Estudiante de carreras técnicas como administración de empresas y carreras afines.'), (NULL, 'Experiencia mínima de 6 meses en labores de análisis.'), (NULL, 'Disponibilidad inmediata.'), (NULL, 'Mayor de 25 años, menor de 40 años.');

INSERT INTO `fa_requisitominimo_cargo` (`cp_requisitominimo_cargo`, `cf_cargo`, `cf_requisitominimo`) VALUES (NULL, '1', '1'), (NULL, '1', '2'), (NULL, '1', '3'), (NULL, '1', '4'), (NULL, '1', '5'), (NULL, '1', '6');

INSERT INTO `fa_tarea` (`cp_tarea`, `atr_descripcion`) VALUES (NULL, 'Efectuar cotizaciones y preparar constantemente propuestas económicas para licitaciones.'), (NULL, 'Realizar levantamiento de información, comercial, financiera y técnica para analizar y preparar contratos y licitaciones.'), (NULL, 'Calcular tarifas para cada tipo de contrato.'), (NULL, 'Realizar gestión administrativa correspondiente a documentos requeridos para cerrar propuestas y levantar nuevos negocios.'), (NULL, 'Evaluar y completar anexos de licitaciones que se subirán.');

INSERT INTO `fa_tareas_cargo` (`cp_tareas_cargo`, `cf_cargo`, `cf_tarea`) VALUES (NULL, '1', '1'), (NULL, '1', '2'), (NULL, '1', '3'), (NULL, '1', '4'), (NULL, '1', '5');

INSERT INTO `fa_conocimiento` (`cp_conocimiento`, `atr_descripcion`) VALUES (NULL, 'Excelente redacción y ortografía pues deberá efectuar informes internos y propuestas para licitaciones.'), (NULL, 'Manejo de Microsoft office nivel avanzado (dominio de tablas dinámicas).'), (NULL, 'Manejo de indicadores financieros, tales como: UF, UTM, entre otros.'), (NULL, 'Evaluación de proyectos y gestión de base de datos.');

INSERT INTO `fa_conocimiento_cargo` (`cp_conocimiento_cargo`, `cf_cargo`, `cf_conocimiento`) VALUES (NULL, '1', '1'), (NULL, '1', '2'), (NULL, '1', '3'), (NULL, '1', '4');

INSERT INTO `fa_titulo` (`cp_titulo`, `atr_descripcion`, `cf_cargo`) VALUES (NULL, 'Tiempo de duración por licitación', '1');

INSERT INTO `fa_otrosantecedentes` (`cp_otrosantecedentes`, `atr_descripcion`, `cf_titulo`, `cf_cargo`) VALUES (NULL, 'En leer, revisar si va la licitación: 5 minutos', '1', '1'), (NULL, 'En subir la licitación: puede demorar entre medio día y una hora.', '1', '1');

INSERT INTO `fa_responsabilidad` (`cp_responsabilidad`, `atr_descripcion`, `cf_cargo`) VALUES (NULL, 'Revisar licitaciones públicas y privadas, subir o generar oferta de las mismas.', '1');
