var base_url = 'https://firmaabogadoschile.tudesarrollo.cl/';

/*************************** TRABAJADOR ****************************/
